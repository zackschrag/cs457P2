#ifndef P2_H
#define P2_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <iostream>
#include <string>
#include <string.h>
#include <fstream>
#include <map>
#include <vector>
#include <iterator>
#include <pthread.h>
#include <fcntl.h>

using std::cin;
using std::cout;
using std::cerr;
using std::endl;
using std::string;
using std::ifstream;
using std::ofstream;
using std::ios;
using std::map;
using std::pair;
using std::vector;

#endif
